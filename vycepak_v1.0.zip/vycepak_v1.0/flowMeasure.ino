void flowMeasure(){


  unsigned long currentMillis = millis();
  if (currentMillis - lastPrint >= 1000) { // Every second
    noInterrupts();
    uint32_t pulses = pulseCount;
    pulseCount = 0;
    interrupts();

    float flowLiters = pulses / PULSES_PER_LITER;
    totalLiters += flowLiters;
    totalMiliLiters = totalLiters * 1000;

      

    Serial.print("Flow this second (L): ");
    Serial.println(flowLiters, 4);
    Serial.print("Total flow (L): ");
    Serial.println(totalMiliLiters);

    sendCommand();
    Serial2.print("n4_0.val=");
    Serial2.print(totalMiliLiters);
    sendCommand();

    sendCommand();
    Serial2.print("nCalMl.val=");
    Serial2.print(totalMiliLiters);
    sendCommand();
  
  
    lastPrint = currentMillis;

    if(calReady == true){
      calWrite();

      }
       
    }


  }
