void loadKegData(){
    
    kegVolume = EEPROM.get(kegADDR,kegVolume);
    EEPROM.commit();
    Serial.print("EEPROM value: ");
    Serial.println(kegVolume);
    Serial.print("uuuuund ");
    
    /*samKegLitres = EEPROM.get(samKegADDR, samKegLiters);
    jenaKegLitres = EEPROM.get(jenaKegADDR, jenaKegLiters);
    misaKegLitres = EEPROM.get(misaKegADDR, misaKegLiters);
    tomKegLitres = EEPROM.get(tomKegADDR, tomKegLiters);
    skalaKegLitres = EEPROM.get(skalaKegADDR, skalaKegLiters);
    cikKegLitres = EEPROM.get(cikKegADDR, cikKegLiters);
    liborKegLitres = EEPROM.get(liborKegADDR, liborKegLiters);*/

    sendCommand();
    Serial2.print("x4_0.val=");
    Serial2.print(kegVolume);
    sendCommand(); 
  
}