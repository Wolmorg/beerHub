void batteryCheck(){
  int batValue = analogRead(batPin);
  int threshold = 2100;
  int hysteresis = 50;
  if(batValue >= (threshold + hysteresis)){
    digitalWrite(gLED, HIGH);
    digitalWrite(rLED, LOW);
  }
  else if (batValue <= (threshold - hysteresis)){
    digitalWrite(gLED, LOW);
    digitalWrite(rLED, HIGH);
  }
}