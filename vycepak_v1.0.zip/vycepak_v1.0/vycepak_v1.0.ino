//Vycepak v1.0

#include <SPI.h>
#include <MFRC522.h>
#include <EEPROM.h>



#define EEPROM_SIZE 128  // You must define the size before calling begin()
#define kegADDR 0 //Adress where volume of current Keg is  stored

#define samLeadADDR 36  // Adress where Sams overall performance is stored
#define samKegADDR 4 // Adress where Sams current performance is stored

#define jenaLeadADDR 40
#define jenaKegADDR 8

#define misaLeadADDR 44
#define misaKegADDR 12

#define tomLeadADDR 48
#define tomKegADDR 16

#define skalaLeadADDR 52
#define skalaKegADDR 20

#define cikLeadADDR 56
#define cikKegADDR 24

#define leeLeadADDR 60
#define leeKegADDR 28

#define liborLeadADDR 64
#define liborKegADDR 32

#define gLED 27
#define rLED 14

#define batPin 34
#define piezo 33


#define SS_PIN  5    // SDA pin for RC522
#define RST_PIN 21   // Reset pin for RC522

MFRC522 rfid(SS_PIN, RST_PIN);



bool samReady = false;
bool jenaReady = false;
bool misaReady = false;
bool tomReady = false;
bool skalaReady = false;
bool cikReady = false;
bool leeReady = false;
bool liborReady = false;
bool rfidReady = false;
bool flowReady = false;
bool calReady = false;

String userid;
String samID = "35f0cb1";
String jenaID = "cbddcb1";
String misaID = "98539699";
String tomID = "c380a15";
String skalaID = "3af54f";
String cikID = "4c80e84";
String leeID = "a17ce54";
String liborID = "5bceaf2";
String prukazID = "12457465";

volatile uint32_t pulseCount = 0;
const byte FLOW_SENSOR_PIN = 25; 
float PULSES_PER_LITER = 450.0; 
unsigned long lastPrint = 0;

float totalLiters = 0;
int totalMiliLiters =0;


int samLeadLitres;
int jenaLeadLitres;
int misaLeadLitres;
int tomLeadLitres;
int skalaLeadLitres;
int cikLeadLitres;
int leeLeadLitres;
int liborLeadLitres;

int samKegLitres;
int jenaKegLitres;
int misaKegLitres;
int tomKegLitres;
int skalaKegLitres;
int cikKegLitres;
int leeKegLitres;
int liborKegLitres;

int kegVolume;
//int kegRest;

void IRAM_ATTR onPulse() {
  pulseCount++;
}

void setup() {

  

  EEPROM.begin(EEPROM_SIZE);
  pinMode(FLOW_SENSOR_PIN, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(FLOW_SENSOR_PIN), onPulse, RISING);
  
  Serial.begin(115200);
  Serial.println("Pivu Zdar");
  Serial2.begin(9600, SERIAL_8N1, 16, 17);
  SPI.begin();          // Init SPI bus
  rfid.PCD_Init();      // Init RC522

  pinMode(gLED, OUTPUT);
  pinMode(rLED, OUTPUT);
  pinMode(piezo, OUTPUT);

  digitalWrite(gLED, HIGH);
  digitalWrite(rLED, LOW);
  
}

void loop() {

   

    if(Serial2.available()){
    String cmd ="";
    delay(30);
    while(Serial2.available()){
      cmd += char(Serial2.read());
    }
    Serial2.println(cmd);
    sendData(cmd);
    Serial.println(cmd);
  
     
  }

    if(rfidReady == true){
      uidRead();
    }
  
    if(flowReady == true){
      flowMeasure();
    }
    else{

    }

    batteryCheck();
         
    
}
