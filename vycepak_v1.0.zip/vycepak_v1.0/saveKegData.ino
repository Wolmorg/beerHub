void tripakSave(int tripakKegLitres, int tripakKegADDR, int tripakLeadLitres, int tripakLeadADDR){
    tripakKegLitres = EEPROM.read(tripakKegADDR);
    tripakKegLitres += totalMiliLiters;
    EEPROM.put(tripakKegADDR, tripakKegLitres);
    EEPROM.commit();
    Serial.print("Na adresu ");
    Serial.print(tripakKegADDR);
    Serial.print(" zapsana hodnota ");
    Serial.print(tripakKegLitres);

    tripakLeadLitres = EEPROM.read(tripakLeadADDR);
    tripakLeadLitres += totalMiliLiters;
    EEPROM.put(tripakLeadADDR, tripakLeadLitres);
    EEPROM.commit();
    Serial.print("Na adresu ");
    Serial.print(tripakLeadADDR);
    Serial.print(" zapsana hodnota ");
    Serial.print(tripakLeadLitres);


  }



void saveKegData(){

  kegVolume = EEPROM.get(kegADDR,kegVolume);
  EEPROM.commit();

  kegVolume -= totalMiliLiters;
  EEPROM.put(kegADDR, kegVolume);
  EEPROM.commit();
  Serial.print("Saving remainder of beer: ");
  Serial.println(kegVolume);
  Serial.println("....");

  sendCommand();
  Serial2.print("x4_0.val=");
  Serial2.print(kegVolume);
  sendCommand();

  

   if(samReady == true){
      tripakSave(samKegLitres, samKegADDR, samLeadLitres, samLeadADDR); 
    }
    else if(jenaReady == true){
      tripakSave(jenaKegLitres, jenaKegADDR, jenaLeadLitres, jenaLeadADDR); 
      
    }
    else if(misaReady == true){
      tripakSave(misaKegLitres, misaKegADDR, misaLeadLitres, misaLeadADDR);   

    }
    else if(tomReady == true){
      tripakSave(tomKegLitres, tomKegADDR, tomLeadLitres, tomLeadADDR);  
    }
    else if(skalaReady == true){
      tripakSave(skalaKegLitres, skalaKegADDR, skalaLeadLitres, skalaLeadADDR);   
    }
    else if(cikReady == true){
      tripakSave(cikKegLitres, cikKegADDR, cikLeadLitres, cikLeadADDR);  
    }
    else if(leeReady == true){
      tripakSave(leeKegLitres, leeKegADDR, leeLeadLitres, leeLeadADDR);  
    }
    else if(liborReady == true){
      tripakSave(liborKegLitres, liborKegADDR, liborLeadLitres, liborLeadADDR); 
    }

 
    totalMiliLiters = 0;
    totalLiters = 0;
    
}

