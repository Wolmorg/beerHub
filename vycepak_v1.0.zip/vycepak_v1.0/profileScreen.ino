void tripakScreen(String picture, String text, int tripakKegADDR, int tripakKegLiters){

    sendCommand();
    Serial2.print("page beerScreen");
    sendCommand();

    sendCommand();
    Serial2.print(picture);
    sendCommand();

    sendCommand();
    Serial2.print("ref p3_0");
    
    sendCommand();
    Serial2.print("t3_1.txt=\"" + text +"\"");
    sendCommand();

    EEPROM.get(tripakKegADDR, tripakKegLiters);
    sendCommand();

    Serial2.print("x5_0.val=");
    Serial2.print(tripakKegLiters);
    sendCommand();



}


void profileScreen(){

    if(samReady == true){

    tripakScreen("p3_0.pic=3","Sam", samKegADDR, samKegLitres);

    /*sendCommand();
    Serial2.print("page beerScreen");
    sendCommand();
      
    sendCommand();
    Serial2.print("p3_0.pic=3");
    
    sendCommand();
    Serial2.print("ref p3_0");
    
    sendCommand();
    Serial2.print("t3_1.txt=\"Sam\"");
    sendCommand();*/

    }

    if(jenaReady == true){

    tripakScreen("p3_0.pic=4","Jena", jenaKegADDR, jenaKegLitres);

    /*sendCommand();
    Serial2.print("page beerScreen");
    sendCommand();
      
    sendCommand();
    Serial2.print("p3_0.pic=4");
    
    sendCommand();
    Serial2.print("ref p3_0");
    
    sendCommand();
    Serial2.print("t3_1.txt=\"Jena\"");
    sendCommand();*/

    }
    

    

    if(misaReady == true){

    tripakScreen("p3_0.pic=7","Misa", misaKegADDR, misaKegLitres);

    /*misaKegLitres = EEPROM.read(misaKegADDR);
   
    sendCommand();
    Serial2.print("page beerScreen");
    sendCommand();
      
    sendCommand();
    Serial2.print("p3_0.pic=7");
    
    sendCommand();
    Serial2.print("ref p3_0");
    
    sendCommand();
    Serial2.print("t3_1.txt=\"Misa\"");
    sendCommand();

    int valMisa = EEPROM.read(misaKegADDR);
    sendCommand();
    Serial2.print("x5_0.val=");
    Serial2.print(valMisa);
    sendCommand();*/

    
    }

    if(tomReady == true){
    
    tripakScreen("p3_0.pic=10","Tom", tomKegADDR, tomKegLitres);

    /*sendCommand();
    Serial2.print("page beerScreen");
    sendCommand();
      
    sendCommand();
    Serial2.print("p3_0.pic=10");
    
    sendCommand();
    Serial2.print("ref p3_0");
    
    sendCommand();
    Serial2.print("t3_1.txt=\"Tom\"");
    sendCommand();*/

    }

    if(skalaReady == true){

    tripakScreen("p3_0.pic=6","Skala", skalaKegADDR, skalaKegLitres);

    /*sendCommand();
    Serial2.print("page beerScreen");
    sendCommand();
      
    sendCommand();
    Serial2.print("p3_0.pic=6");
    
    sendCommand();
    Serial2.print("ref p3_0");
    
    sendCommand();
    Serial2.print("t3_1.txt=\"Skala\"");
    sendCommand();*/

    }

    

    if(cikReady == true){

    tripakScreen("p3_0.pic=5","Cik", cikKegADDR, cikKegLitres);

    /*sendCommand();
    Serial2.print("page beerScreen");
    sendCommand();
      
    sendCommand();
    Serial2.print("p3_0.pic=5");
    
    sendCommand();
    Serial2.print("ref p3_0");
    
    sendCommand();
    Serial2.print("t3_1.txt=\"Cik\"");
    sendCommand();*/

    }


    if(leeReady == true){

    tripakScreen("p3_0.pic=9","Lee", leeKegADDR, leeKegLitres);
    /*sendCommand();
    Serial2.print("page beerScreen");
    sendCommand();
      
    sendCommand();
    Serial2.print("p3_0.pic=9");
    
    sendCommand();
    Serial2.print("ref p3_0");
    
    sendCommand();
    Serial2.print("t3_1.txt=\"Lee\"");
    sendCommand();*/

    }

    if(liborReady == true){

    tripakScreen("p3_0.pic=8","Libor", liborKegADDR, liborKegLitres);

    /*sendCommand();
    Serial2.print("page beerScreen");
    sendCommand();
      
    sendCommand();
    Serial2.print("p3_0.pic=8");
    
    sendCommand();
    Serial2.print("ref p3_0");
    
    sendCommand();
    Serial2.print("t3_1.txt=\"Libor\"");
    sendCommand();*/

    }
    
    
   

    
       
}