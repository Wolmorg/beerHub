void calWrite(){

    sendCommand();
    Serial2.print("nCalMl=");
    Serial2.print(totalMiliLiters);
    sendCommand();


    float calRecommend = ((totalMiliLiters*9)/10);
    int scaledCalValue = calRecommend * 100;

    Serial.println(calRecommend);
    Serial.println(scaledCalValue);
    sendCommand();
    Serial2.print("xCalRecommend.val=");
    Serial2.print(scaledCalValue);
    sendCommand();

    if((calRecommend >= 1) && (calRecommend <= 999)){
        
      sendCommand();
      Serial2.print("nRecCal.bco=1024");
      sendCommand();
        }
    else{

      sendCommand();
      Serial2.print("nRecCal.bco=63488");
      sendCommand();

      }
}