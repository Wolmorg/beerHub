void deleteKegData(){
  int i;
  String eepromVal;
  for(i=0; i<=35; i++){
    EEPROM.put(i,0);
    eepromVal = EEPROM.read(i);
    Serial.println(eepromVal);
  }
  EEPROM.commit();

  
}