void userDetect(){

  if(userid == samID){
    
    flowReady = true;
    samReady = true;
    rfidReady = false;
    profileScreen();
    
   
  }

  if(userid == jenaID){
    flowReady = true;
    jenaReady = true;
    rfidReady = false;
    profileScreen();

  }

  if(userid == misaID){
    

    flowReady = true;
    misaReady = true;
    rfidReady = false;
    profileScreen();
    
   
  }

   if(userid == tomID){
    

    flowReady = true;
    tomReady = true;
    rfidReady = false;
    profileScreen();
    
   
  }

  if(userid == skalaID){
    

    flowReady = true;
    skalaReady = true;
    rfidReady = false;
    profileScreen();
    
   
  }

  if(userid == cikID){
    

    flowReady = true;
    cikReady = true;
    rfidReady = false;
    profileScreen();
    
   
  }

  if(userid == leeID){
    

    flowReady = true;
    leeReady = true;
    rfidReady = false;
    profileScreen();
    
   
  }

  if(userid == liborID){
    

    flowReady = true;
    liborReady = true;
    rfidReady = false;
    profileScreen();
    
   
  }
 
 
}