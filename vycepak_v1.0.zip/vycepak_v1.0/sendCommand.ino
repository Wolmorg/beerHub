void sendCommand(){

  Serial2.write(0xFF);
  Serial2.write(0xFF);
  Serial2.write(0xFF);


}