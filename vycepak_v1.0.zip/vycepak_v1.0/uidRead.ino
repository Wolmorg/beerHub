void uidRead(){


  //Serial.println("Scan a card...");
  if (!rfid.PICC_IsNewCardPresent()) {
    return;
  }
    // Select one of the cards
  if (!rfid.PICC_ReadCardSerial()) {
    return;
  }
      String uidString = "";
      for (byte i = 0; i < rfid.uid.size; i++) {
        uidString += String(rfid.uid.uidByte[i], HEX);  // Convert byte to HEX string
      }

      // Print the UID to the Serial Monitor
      Serial.print("UID: ");
      Serial.println(uidString);
      userid = uidString;  // Print the UID string
      
      userDetect();
      beep();

      rfid.PICC_HaltA();
      rfid.PCD_StopCrypto1();

      while (rfid.PICC_IsNewCardPresent() || rfid.PICC_ReadCardSerial()) {
    delay(50);
    }

  Serial.println("Card removed. Ready for next scan...");
}