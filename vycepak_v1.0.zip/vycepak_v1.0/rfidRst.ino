void rfidRst(){

  totalMiliLiters = 0;
  totalLiters = 0;
  
  samReady = false;
  jenaReady = false;
  misaReady = false;
  tomReady = false;
  skalaReady = false;
  cikReady = false;
  leeReady = false;
  liborReady = false;
  flowReady = false;
  calReady = false;
  
  

}