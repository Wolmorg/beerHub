void memoryErase(){
  int i;
  String eepromVal;
  for(i=0; i<=128; i++){
    EEPROM.put(i,0);
    eepromVal = EEPROM.read(i);
    Serial.println(eepromVal);
  }
  EEPROM.commit();

  sendCommand();
  Serial2.print("tMemErase.txt=\"Pamet Vymazana\"");
  sendCommand();

  
}