void leaderBoards(){
  int SIZE = 9;

  samLeadLitres = EEPROM.get(samLeadADDR, samLeadLitres);
  jenaLeadLitres = EEPROM.get(jenaLeadADDR, jenaLeadLitres);
  misaLeadLitres = EEPROM.get(misaLeadADDR, misaLeadLitres);
  tomLeadLitres = EEPROM.get(tomLeadADDR, tomLeadLitres);
  skalaLeadLitres = EEPROM.get(skalaLeadADDR, skalaLeadLitres);
  cikLeadLitres = EEPROM.get(cikLeadADDR, cikLeadLitres);
  leeLeadLitres = EEPROM.get(leeLeadADDR, leeLeadLitres);
  liborLeadLitres = EEPROM.get(liborLeadADDR, liborLeadLitres);


  int numbers[SIZE] = {samLeadLitres, jenaLeadLitres, misaLeadLitres, tomLeadLitres, skalaLeadLitres, cikLeadLitres, leeLeadLitres, liborLeadLitres};
  String names[SIZE] = {"Sam", "Jena", "Misa", "Tom", "Skala", "Cik", "Lee", "Libor"};

  // Sort numbers from highest to lowest using bubble sort
  for (int i = 0; i < SIZE - 1; i++) {
    for (int j = 0; j < SIZE - 1 - i; j++) {
      if (numbers[j] < numbers[j + 1]) {
        int temp = numbers[j];
        numbers[j] = numbers[j + 1];
        numbers[j + 1] = temp;

        String tempName = names[j];
        names[j] = names[j+1];
        names[j+1] = tempName;
      }
    }
  }

  // Print sorted numbers
  Serial.println("Numbers sorted from highest to lowest:");
  for (int i = 0; i < SIZE; i++) {
    Serial.println(numbers[i]);
    Serial.println(names[i]);
  }

  for (int i = 0; i < SIZE; i++) {
    sendValueToNextion(i, numbers[i]);
    sendNameToNextion(i, names[i]);
  }

  int picID = getPictureIDForWinner(names[0]); // winner is first after sorting
  sendPictureToNextion(picID);

}

  void sendValueToNextion(int index, int value) {
  sendCommand();
  Serial2.print("x7_");
  Serial2.print(index);
  Serial2.print(".val=");
  Serial2.print(value);
  sendCommand();
}

void sendPictureToNextion(int picID) {
  sendCommand();
  Serial2.print("p7_0.pic=");
  Serial2.print(picID);
  sendCommand();
  Serial2.print("ref p7_0");
  sendCommand();
  
}

// Send name to t7_x (text component)
void sendNameToNextion(int index, String name) {
  sendCommand();
  Serial2.print("t7_");
  Serial2.print(index);
  Serial2.print(".txt=\"");
  Serial2.print(name);
  Serial2.print("\"");
  



}

int getPictureIDForWinner(String winnerName) {
  if (winnerName == "Sam"){
    sendCommand();
    Serial2.print("tWinnerName.txt=\"Sam\"");
    sendCommand();
    return 3;
  } 
  else if (winnerName == "Jena"){
    sendCommand();
    Serial2.print("tWinnerName.txt=\"Jena\"");
    sendCommand();
    return 4;
    
  }
  else if (winnerName == "Misa"){
    sendCommand();
    Serial2.print("tWinnerName.txt=\"Misa\"");
    sendCommand();
    return 7;
  } 
  else if (winnerName == "Tom"){
    sendCommand();
    Serial2.print("tWinnerName.txt=\"Tom\"");
    sendCommand();
    return 10;
  }
  else if (winnerName == "Skala"){
    sendCommand();
    Serial2.print("tWinnerName.txt=\"Skala\"");
    sendCommand();
    return 6;
  }
  else if (winnerName == "Cik"){
    sendCommand();
    Serial2.print("tWinnerName.txt=\"Cik\"");
    sendCommand();
    return 5;
  } 
  else if (winnerName == "Lee"){
    sendCommand();
    Serial2.print("tWinnerName.txt=\"Lee\"");
    sendCommand();
    return 9;
  }
  else if (winnerName == "Libor"){
    sendCommand();
    Serial2.print("tWinnerName.txt=\"Libor\"");
    sendCommand();
    return 8;
  }
  // Add more mappings as needed
  else return 2; // default or no picture
}







