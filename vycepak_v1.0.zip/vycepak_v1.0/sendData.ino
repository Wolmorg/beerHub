void sendData(String cmd){


  if(cmd.startsWith("cal")){
    
    int val = cmd.substring(3,6).toInt();
    Serial.print("recieved value: ");
    Serial.println(val);
    PULSES_PER_LITER = val;
    Serial.print("value written to cal constant: ");
    Serial.println(PULSES_PER_LITER);

    String resetPresent = cmd.substring(7);
    if(resetPresent == "rst"){
      rfidRst();
    }
    beep();

  }

  if(cmd.startsWith("kegval")){
    int kegVal = cmd.substring(6,11).toInt();
    Serial.print("volume of Keg is: ");
    Serial.println(kegVal);
    kegVolume = kegVal;
    Serial.println("Objem becky zapsane je: ");
    Serial.println(kegVolume);
    
    sendCommand();
    Serial2.print("x4_0.val=");
    Serial2.print(kegVolume);
    sendCommand();

    EEPROM.put(kegADDR, kegVolume);
    EEPROM.commit();

    String kegReady = cmd.substring(12);
    Serial.println(kegReady);
      if(kegReady == "kegReady"){
        Serial.println("je to tak pane krali");
        rfidReady = true;

        


      }
    beep();
  }


  if(cmd == "dopito"){
    beep();
    rfidReady = true;
    saveKegData();
    rfidRst();
       

  }

  if(cmd == "kegDelete"){
    deleteKegData();
    beep();
    

  }

  if(cmd == "loadKeg"){
    beep();
    rfidReady = true;
    Serial.println("priloz kartu");
    loadKegData();

  }


  if(cmd == "flowCal"){
    totalLiters = 0;
    totalMiliLiters = 0;
    sendCommand();
    Serial2.print("nCalMl.val=");
    Serial2.print(totalMiliLiters);
    sendCommand();
    beep();
    calReady = true;
    flowReady = true;
   
  }

  if(cmd == "loadKeg"){
    loadKegData();
  }



  if(cmd == "rst"){
    rfidRst();
  }

  if(cmd == "leaderBoards"){
    beep();
    leaderBoards();
  }

  if(cmd == "rfidOff"){
    beep();
    rfidReady = false;
  }

  if(cmd == "beep"){
    beep();
  }

  if(cmd == "memoryErase"){
    beep();
    beep();
    beep();
    memoryErase();
  }

  
}